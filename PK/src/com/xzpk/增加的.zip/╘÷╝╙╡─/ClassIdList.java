package com.xzpk;

/**
 * @program: PK
 * @description: 班级列表
 * @author: Mr.Sun
 * @create: 2018-09-26 15:09
 **/
public class ClassIdList {
    private int classID;

    public int getClassID() {
        return classID;
    }

    public void setClassID(int classID) {
        this.classID = classID;
    }
}
