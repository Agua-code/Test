package XZPK;

/**
 * @program: PK
 * @description: 优先排课信息
 * @author: Mr.Sun
 * @create: 2018-09-25 22:06
 **/
public class CtwoCrsListInfo {
    /**
     *需要优先排课的课程的ID
     */
    private int ctwoCrsID;

    public int getCtwoCrsID() {
        return ctwoCrsID;
    }

    public void setCtwoCrsID(int ctwoCrsID) {
        this.ctwoCrsID = ctwoCrsID;
    }

}
