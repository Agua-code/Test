package XZPK;

/**
 * @program: PK
 * @description: 合班的班级信息
 * @author: Mr.Sun
 * @create: 2018-09-25 22:27
 **/
public class HBKClassInfo {
    /**
     *合班的班级ID
     */
    private int hbkClassID;

    public int getHbkClassID() {
        return hbkClassID;
    }

    public void setHbkClassID(int hbkClassID) {
        this.hbkClassID = hbkClassID;
    }


}
