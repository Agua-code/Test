package XZPK;

/**
 * @program: PK
 * @description: 不排课具体时间输入
 * @author: Mr.Sun
 * @create: 2018-09-25 22:24
 **/
public class AvbTimeInfo {
    /**
     *0-1变量
     */
    private int avbTime;

    public int getAvbTime() {
        return avbTime;
    }

    public void setAvbTime(int avbTime) {
        this.avbTime = avbTime;
    }


}
