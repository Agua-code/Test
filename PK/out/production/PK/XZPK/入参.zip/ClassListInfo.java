package XZPK;

/**
 * @program: PK
 * @description: 班级列表输入
 * @author: Mr.Sun
 * @create: 2018-09-25 21:56
 **/
public class ClassListInfo {
    /**
     *班级的ID，需要输入所有的班级
     */
    private int classID;

    public int getClassID() {
        return classID;
    }

    public void setClassID(int classID) {
        this.classID = classID;
    }


}
