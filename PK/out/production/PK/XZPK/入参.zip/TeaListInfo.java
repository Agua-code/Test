package XZPK;

/**
 * @program: PK
 * @description: 教师列表输入
 * @author: Mr.Sun
 * @create: 2018-09-25 22:03
 **/
public class TeaListInfo {
    /**
     *所有教师的Name都需要输入
     */
    private String teaName;

    public String getTeaName() {
        return teaName;
    }

    public void setTeaName(String teaName) {
        this.teaName = teaName;
    }
}
